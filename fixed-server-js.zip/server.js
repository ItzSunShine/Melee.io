
// === server.js ===
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 3000;

app.use(express.static('public'));

let players = {};
let bots = [];
const MAX_BOTS = 10;
const WORLD_WIDTH = 4000;
const WORLD_HEIGHT = 4000;
const SPAWN_PROTECTION_TIME = 5000;

const BOT_NAMES = [
  "Shadow", "Rogue", "Viper", "Phantom", "Hunter", "Blaze",
  "Nova", "Echo", "Rift", "Strike", "Onyx", "Specter",
  "Wraith", "Glitch", "Drift", "Frost", "Ash", "Ember"
];

const BAD_WORDS = ["badword1", "badword2", "offensiveword", "💩", "🖕", "🔞"];
function sanitizeUsername(name) {
  for (let bad of BAD_WORDS) {
    const regex = new RegExp(bad, 'i');
    if (regex.test(name)) return null;
  }
  return name;
}

function isUsernameTaken(name) {
  return Object.values(players).some(p => p.username === name);
}

function generateBot(id) {
  return {
    id,
    username: BOT_NAMES[Math.floor(Math.random() * BOT_NAMES.length)],
    x: Math.random() * WORLD_WIDTH,
    y: Math.random() * WORLD_HEIGHT,
    angle: 0,
    swinging: false,
    xp: 0,
    level: 1,
    bot: true,
    target: null,
    spawnTime: Date.now(),
    latency: 0,
  };
}

function updateBots() {
  bots.forEach(bot => {
    const others = Object.values(players).concat(bots.filter(b => b.id !== bot.id));
    let nearest = null;
    let minDist = Infinity;
    others.forEach(other => {
      const dx = other.x - bot.x;
      const dy = other.y - bot.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < minDist && dist < 300) {
        nearest = other;
        minDist = dist;
      }
    });
    if (nearest) {
      const dx = nearest.x - bot.x;
      const dy = nearest.y - bot.y;
      bot.angle = Math.atan2(dy, dx);
      bot.x += Math.cos(bot.angle) * 2;
      bot.y += Math.sin(bot.angle) * 2;
      bot.swinging = Math.random() < 0.05;

      if (bot.swinging && minDist < 60) {
        const now = Date.now();
        const isProtected = !bot.bot && now - (bot.spawnTime || 0) < SPAWN_PROTECTION_TIME;
        const isTargetProtected = !nearest.bot && now - (nearest.spawnTime || 0) < SPAWN_PROTECTION_TIME;

        if (!isProtected && !isTargetProtected) {
          bot.xp += 25;
          if (bot.xp >= bot.level * 100) bot.level++;

          if (!nearest.bot) {
            io.to(nearest.id).emit('killed');
          } else {
            bots = bots.filter(b => b.id !== nearest.id);
          }
        }
      }
    } else {
      bot.swinging = false;
    }
  });

  io.emit('updateBots', bots);
}

setInterval(() => {
  if (Object.keys(players).length < 4 && bots.length < MAX_BOTS) {
    const botId = 'bot_' + Date.now();
    const bot = generateBot(botId);
    bots.push(bot);
  }
  updateBots();
}, 100);

io.on('connection', socket => {
  console.log(`Player connected: ${socket.id}`);

  function spawnPlayer(username = "Player" + Math.floor(Math.random() * 1000)) {
    players[socket.id] = {
      id: socket.id,
      username,
      x: Math.random() * WORLD_WIDTH,
      y: Math.random() * WORLD_HEIGHT,
      angle: 0,
      swinging: false,
      xp: 0,
      level: 1,
      bot: false,
      spawnTime: Date.now(),
      latency: 0,
    };
  }

  spawnPlayer();
  socket.emit('currentPlayers', players);
  socket.broadcast.emit('newPlayer', players[socket.id]);

  let pingInterval = setInterval(() => {
    socket.emit('pingCheck', Date.now());
  }, 1000);

  socket.on('setUsername', name => {
    const clean = sanitizeUsername(name);
    if (!clean || isUsernameTaken(clean)) {
      socket.emit('usernameRejected');
    } else if (players[socket.id]) {
      players[socket.id].username = clean;
      socket.emit('usernameAccepted', clean);
    }
  });

  socket.on('pongCheck', startTime => {
    const latency = Date.now() - startTime;
    if (players[socket.id]) {
      players[socket.id].latency = latency;
    }
    socket.emit('latency', latency);
    socket.broadcast.emit('latencyUpdate', { id: socket.id, latency });
  });

  socket.on('move', data => {
    if (players[socket.id]) {
      const now = Date.now();
      players[socket.id].x = data.x;
      players[socket.id].y = data.y;
      players[socket.id].angle = data.angle;
      players[socket.id].swinging = data.swinging;

      if (data.swinging) {
        for (const [id, other] of Object.entries(players)) {
          if (id !== socket.id) {
            const dx = other.x - data.x;
            const dy = other.y - data.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            const isProtected = now - (other.spawnTime || 0) < SPAWN_PROTECTION_TIME || now - (players[socket.id].spawnTime || 0) < SPAWN_PROTECTION_TIME;
            if (dist < 60 && !isProtected) {
              players[socket.id].xp += 50;
              if (players[socket.id].xp >= players[socket.id].level * 100) players[socket.id].level++;
              io.to(id).emit('killed');
            }
          }
        }

        bots.forEach((bot, i) => {
          const dx = bot.x - data.x;
          const dy = bot.y - data.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          const isProtected = now - (players[socket.id].spawnTime || 0) < SPAWN_PROTECTION_TIME || now - (bot.spawnTime || 0) < SPAWN_PROTECTION_TIME;
          if (dist < 60 && !isProtected) {
            players[socket.id].xp += 25;
            if (players[socket.id].xp >= players[socket.id].level * 100) players[socket.id].level++;
            bots.splice(i, 1);
          }
        });
      }

      socket.broadcast.emit('playerMoved', { id: socket.id, ...players[socket.id] });
    }
  });

  socket.on('respawn', () => {
    spawnPlayer(players[socket.id]?.username);
    socket.emit('currentPlayers', players);
    socket.broadcast.emit('newPlayer', players[socket.id]);
  });

  socket.on('disconnect', () => {
    console.log(`Player disconnected: ${socket.id}`);
    delete players[socket.id];
    io.emit('playerDisconnected', socket.id);
    clearInterval(pingInterval);
  });
});

server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
